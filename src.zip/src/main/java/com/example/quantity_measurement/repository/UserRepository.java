package com.example.quantity_measurement.repository;

import com.example.quantity_measurement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // ✅ Find user by email (used in Google login)
    Optional<User> findByEmail(String email);
}