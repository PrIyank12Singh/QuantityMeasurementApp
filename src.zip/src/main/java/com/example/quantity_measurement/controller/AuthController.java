package com.example.quantity_measurement.controller;

import com.example.quantity_measurement.service.GoogleAuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final GoogleAuthService googleAuthService;

    public AuthController(GoogleAuthService googleAuthService) {
        this.googleAuthService = googleAuthService;
    }

    // ✅ Endpoint for Google login
    @PostMapping("/google")
    public ResponseEntity<Map<String, Object>> googleLogin(@RequestBody Map<String, String> body) {
        String token = body.get("idToken");  // frontend sends { "idToken": "..." }
        Map<String, Object> userData = googleAuthService.verifyToken(token);
        return ResponseEntity.ok(userData);
    }

    // Optional: simple health check
    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("Auth service is running");
    }
}